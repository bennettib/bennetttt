var months			= ['Janeiro','Fevereiro','Março','Abril','Mayıs','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
	days			= ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
	errorMessage	= 'Error loading events...';
